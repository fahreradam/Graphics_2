from django.contrib import admin
from django.urls import path
import about
import home

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home.view ),
    path('about', about.view )
]