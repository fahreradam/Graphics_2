import django.test

class MyTester(django.test.TestCase):
    def test_about(self):
        c = django.test.Client()
        resp = c.get("/about")
        rstr = resp.content.decode()
        self.assertTrue("Bob" in rstr)