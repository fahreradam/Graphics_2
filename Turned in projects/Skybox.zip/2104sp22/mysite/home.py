import django.shortcuts

def view(request):
    return django.shortcuts.redirect("/static/home.html")