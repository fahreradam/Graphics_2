# put this in Buffer.py
from gl import *
from glconstants import *
import array


class Buffer:
    def __init__(self, data, usage=GL_STATIC_DRAW):
        # I = type code (integers
        tmp = array.array("I", [0])
        glGenBuffers(1, tmp)
        self.buffID = tmp[0]  # the name of my buffer
        glBindBuffer(GL_ARRAY_BUFFER, self.buffID)

        # antibugging
        assert type(data) == array.array  # If data is not an array then the program will stop
        tmp = data.tobytes()
        # Which binding point
        glBufferData(GL_ARRAY_BUFFER, len(tmp), tmp, usage)

        glBindBuffer(GL_ARRAY_BUFFER, 0)

    def bind(self, target):
        glBindBuffer(target, self.buffID)

    def bindBase(self, target, index):
        glBindBufferBase(target, index, self.buffID)
