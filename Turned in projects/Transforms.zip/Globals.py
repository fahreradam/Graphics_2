from Environment import Bouncers
from Environment import Player


class GlobalVariables:
    def __init__(self):
        # put globals here...
        self.keys = set()
        self.box_x = 200
        self.box_y = 200
        self.bouncer = Bouncers()
        self.player = Player()
