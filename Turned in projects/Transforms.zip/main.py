# this one *must* be first
import ctypes
import sys

import etgg2801

import pysdl2.sdl2 as sdl2
import pysdl2.sdl2.keycode as keycode
from gl import *
from glconstants import *
import time
import Globals
import ctypes
from StateMachine import BulletStateMachine
import BufferManager
from Environment import Emitter
from Environment import Hexagons
from Environment import Bouncers
from Environment import Player
from Program import Program
from Mesh import Mesh
from math2801 import *


def main() -> None:
    win = etgg2801.createWindow()
    print(glGetString(GL_RENDERER), glGetString(GL_VENDOR), glGetString(GL_VERSION),
          glGetString(GL_SHADING_LANGUAGE_VERSION))
    DESIRED_FRAMES_PER_SEC = 60
    DESIRED_SEC_PER_FRAME = 1 / DESIRED_FRAMES_PER_SEC
    globs = Globals.GlobalVariables()
    globs.bulletStateMachine = BulletStateMachine()
    globs.emitter = Emitter(5)
    globs.hex = Hexagons()
    setup(globs)
    last = time.time_ns() / 1000000000
    QUANTUM = 0.005
    accumulated = 0
    while True:
        now = time.time_ns() / 1000000000
        elapsed = now - last
        last = now
        accumulated += elapsed
        while accumulated >= QUANTUM:
            update(elapsed, globs)
            accumulated -= QUANTUM
        draw(globs)
        sdl2.SDL_GL_SwapWindow(win)
        end = time.time_ns() / 1000000000
        frameTime = end - now
        leftover = DESIRED_SEC_PER_FRAME - frameTime
        if leftover > 0:
            time.sleep(leftover)


def setup(globs):
    globs.prog = Program(vs="vs.txt", fs="fs.txt")
    globs.hex.setup()
    triverts = [0, 0.9, 0, 0.5, -0.4, 0, -0.5, 0, 0]

    quadverts = [0.6, 0.9, 0,  # upper left
                 0.6, 0.7, 0,  # lower left
                 0.8, 0.9, 0,  # upper right

                 0.8, 0.7, 0,  # lower right
                 0.8, 0.9, 0,  # upper right
                 0.9, 0.7, 0]  # lower left

    # BufferManager.addData(triverts)
    # BufferManager.addData(quadverts)
    #
    # BufferManager.pushToGPU()

    glEnable(GL_SCISSOR_TEST)

    glClearColor(0, 0, 0, 1)


def update(elapsed, globs):
    keysBefore = set(globs.keys)
    pumpEvents(globs)

    globs.emitter.update(elapsed)
    globs.player.update()
    # Exiting with Escape
    if keycode.SDLK_ESCAPE in globs.keys:
        sdl2.SDL_QUIT()
        sys.exit()

    # Movement
    if keycode.SDLK_d in globs.keys:
        globs.player.position.x = globs.player.position.x + globs.player.speed * elapsed
    if keycode.SDLK_w in globs.keys:
        globs.player.position.y = globs.player.position.y + globs.player.speed * elapsed
    if keycode.SDLK_s in globs.keys:
        globs.player.position.y = globs.player.position.y - globs.player.speed * elapsed
    if keycode.SDLK_a in globs.keys:
        globs.player.position.x = globs.player.position.x - globs.player.speed * elapsed

    globs.bulletStateMachine.update(keysBefore, globs.keys, elapsed)


def pumpEvents(globs):
    ev = sdl2.SDL_Event()
    while True:
        eventOccurred = sdl2.SDL_PollEvent(ctypes.byref(ev))
        if not eventOccurred:
            return
        elif ev.type == sdl2.SDL_KEYDOWN:
            globs.keys.add(ev.key.keysym.sym)
        elif ev.type == sdl2.SDL_KEYUP:
            globs.keys.discard(ev.key.keysym.sym)
        elif ev.type == sdl2.SDL_QUIT:
            sdl2.SDL_Quit()
            sys.exit()


def draw(globs):
    glClear(GL_COLOR_BUFFER_BIT)
    BufferManager.bind()
    globs.prog.use()
    # globs.hex.draw()

    # glDrawArrays(GL_TRIANGLES, 0, 3)

    # glClear(GL_COLOR_BUFFER_BIT) glScissor(globs.box_x, globs.box_y, 50, 50) glClearColor(
    # globs.bulletStateMachine.chargeAmount, globs.bulletStateMachine.green, globs.bulletStateMachine.blue,
    # 0) glClear(GL_COLOR_BUFFER_BIT)
    # globs.player.draw()
    # Program.setUniform("position", vec3(globs.bouncer.position[0], globs.bouncer.position[1], 1))
    globs.emitter.draw()
    globs.player.draw(vec3(globs.bulletStateMachine.chargeAmount, globs.bulletStateMachine.green, globs.bulletStateMachine.blue))
    # glScissor(0, 0, 512, 512)
    # glClearColor(0, 0, 0, 0)


main()
