import os.path
import itertools
import BufferManager
from gl import *
from glconstants import *


class Mesh:
    def __init__(self, fname):
        fullfname = os.path.join(os.path.dirname(__file__),
                                 "assets",
                                 fname)

        positions = []
        indices = []

        with open(fullfname) as fp:
            # use fp to read from file
            for line in fp:
                line = line.strip()
                # space so we don't catch vt or vn
                if line.startswith("v "):
                    tmp3 = [float(q) for q in line.split()[1:4]]
                    positions.append(tmp3)
                elif line.startswith("f"):
                    tmp = line.split()
                    if len(tmp) != 4:
                        raise RuntimeError("Non triangle in {}".format(fname))
                    for thing in tmp[1:]:
                        tmp3 = thing.split("/")
                        idx = tmp3[0]
                        idx = int(idx)
                        idx -= 1
                        indices.append(idx)
                else:
                    pass

            # end for
        # endwith
        flatlist = list(itertools.chain.from_iterable(positions))
        self.numIndecies = len(indices)
        self.vertexOffset, self.indexStart = BufferManager.addIndexedData(positiondata=flatlist,
                                                                          indexdata=indices)

    def draw(self):
        glDrawElementsBaseVertex(GL_TRIANGLES, self.numIndecies, GL_UNSIGNED_INT, self.indexStart, self.vertexOffset)
