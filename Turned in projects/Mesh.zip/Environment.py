import random
import pysdl2.sdl2 as sdl2
import pysdl2.sdl2.keycode as keycode
from gl import *
from glconstants import *
import BufferManager
from Mesh import Mesh

class Emitter:
    def __init__(self, amount_num):
        self.squares = []
        self.amount = amount_num
        self.run = True
        while self.run:
            self.squares.append(Bouncers())
            if len(self.squares) == self.amount:
                self.run = False

    def draw(self):
        for d in self.squares:
            d.draw()

    def update(self, elapsed):
        for u in self.squares:
            u.update(elapsed)


class Player:
    mesh = Mesh("stickfigure.obj")

    def __init__(self):
        self.direction = []
        self.position = []
        self.size = []

    def draw(self):
        Player.mesh.draw()

class Bouncers:
    mesh = Mesh("virus.obj")

    def __init__(self):
        self.direction = [random.randint(-1, 1), random.randint(-1, 1)]
        self.position = [random.randint(100, 400), random.randint(100, 400)]
        self.speed = 1
        self.color = (1, 0, 1, 0)
        self.size = 5


    def update(self, elapsed):
        self.position[0] += self.speed * self.direction[0]
        self.position[1] += self.speed * self.direction[1]
        if self.position[0] <= 0:
            self.direction[0] *= -1
        if self.position[0] >= 512 - self.size:
            self.direction[0] *= -1
        if self.position[1] <= 0:
            self.direction[1] *= -1
        if self.position[1] >= 512 - self.size:
            self.direction[1] *= -1

    def draw(self):
        # glScissor(self.position[0], self.position[1], self.size, self.size)
        # glClearColor(*self.color)
        # glClear(GL_COLOR_BUFFER_BIT)
        Bouncers.mesh.draw()


class Hexagons:
    def __init__(self):
        self.center_point = [0, 0]
        self.position = [self.center_point[0] - 0.2, self.center_point[1] + 0.35, 0,  # Top
                         self.center_point[0] + 0.2, self.center_point[1] + 0.35, 0,  # Top
                         self.center_point[0], self.center_point[1], 0,  # Top
                         self.center_point[0] + 0.2, self.center_point[1] + 0.35, 0,
                         self.center_point[0] + 0.4, self.center_point[1], 0,
                         self.center_point[0], self.center_point[1], 0,
                         self.center_point[0] + 0.2, self.center_point[1] - 0.35, 0,
                         self.center_point[0] + 0.4, self.center_point[1], 0,
                         self.center_point[0], self.center_point[1], 0,
                         self.center_point[0] - 0.2, self.center_point[1] + 0.35, 0,
                         self.center_point[0] - 0.4, self.center_point[1], 0,
                         self.center_point[0], self.center_point[1], 0,
                         self.center_point[0] - 0.2, self.center_point[1] - 0.35, 0,
                         self.center_point[0] - 0.4, self.center_point[1], 0,
                         self.center_point[0], self.center_point[1], 0,
                         self.center_point[0] - 0.2, self.center_point[1] - 0.35, 0,
                         self.center_point[0] + 0.2, self.center_point[1] - 0.35, 0,
                         self.center_point[0], self.center_point[1], 0]
        self.positiondata = [self.center_point[0], self.center_point[1], 0,
                             self.center_point[0] - 0.2, self.center_point[1] + 0.35, 0,
                             self.center_point[0] + 0.2, self.center_point[1] + 0.35, 0,
                             self.center_point[0] + 0.4, 0, 0,
                             self.center_point[0] + 0.2, self.center_point[1] - 0.35, 0,
                             self.center_point[0] - 0.2, self.center_point[1] - 0.35, 0,
                             self.center_point[0] - 0.4, 0, 0]
        self.index = [1, 0, 2, 2, 0, 3, 3, 0, 4, 4, 0, 5, 5, 0, 6, 6, 0, 1]
        self.startingVertexNumber, self.indexOffset = BufferManager.addIndexedData(positiondata=self.positiondata, indexdata=self.index)

    def setup(self):
        BufferManager.addData(self.position)
        BufferManager.pushToGPU()

    def draw(self):
        glDrawElementsBaseVertex(GL_TRIANGLES, 18, GL_UNSIGNED_INT, self.indexOffset, self.startingVertexNumber)


