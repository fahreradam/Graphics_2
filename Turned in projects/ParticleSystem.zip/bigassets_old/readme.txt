This folder is for large art assets.
