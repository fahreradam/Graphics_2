# this one *must* be first
import ctypes
import sys

import etgg2801

import pysdl2.sdl2 as sdl2
import pysdl2.sdl2.keycode as keycode
import texture
from gl import *
from glconstants import *
import time
import Globals
import ctypes
from StateMachine import BulletStateMachine
import BufferManager
from Environment import Emitter
from Environment import Hexagons
from Environment import Virus
from Environment import Player
from Program import Program
from Mesh import Mesh
from math2801 import *
import Sampler
from Environment import Bullet
from texture import ImageTexture2DArray
import Text


def main() -> None:
    win = etgg2801.createWindow()
    print(glGetString(GL_RENDERER), glGetString(GL_VENDOR), glGetString(GL_VERSION),
          glGetString(GL_SHADING_LANGUAGE_VERSION))
    DESIRED_FRAMES_PER_SEC = 60
    DESIRED_SEC_PER_FRAME = 1 / DESIRED_FRAMES_PER_SEC
    globs = Globals.GlobalVariables()
    globs.bulletStateMachine = BulletStateMachine()
    globs.emitter = Emitter(5)
    globs.bullet = Bullet(globs.player.position)
    setup(globs)
    last = time.time_ns() / 1000000000
    QUANTUM = 0.005
    accumulated = 0
    while True:
        now = time.time_ns() / 1000000000
        elapsed = now - last
        last = now
        accumulated += elapsed
        while accumulated >= QUANTUM:
            update(elapsed, globs)
            accumulated -= QUANTUM
        draw(globs)
        sdl2.SDL_GL_SwapWindow(win)
        end = time.time_ns() / 1000000000
        frameTime = end - now
        leftover = DESIRED_SEC_PER_FRAME - frameTime
        if leftover > 0:
            time.sleep(leftover)


def setup(globs):
    #globs.framecount = 0


    Text.initialize()
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    globs.prog = Program(vs="vs.txt", fs="fs.txt")

    # BufferManager.addData(triverts)
    # BufferManager.addData(quadverts)
    #
    # BufferManager.pushToGPU()

    # nearestSampler = Sampler.NearestSampler()
    # nearestSampler.bind(0)
    mipsamp = Sampler.NearestSampler()
    mipsamp.bind(0)
    nsamp = Sampler.NearestSampler()
    nsamp.bind(15)


    glEnable(GL_SCISSOR_TEST)

    glClearColor(0, 0, 0, 1)
    BufferManager.pushToGPU()

    Text.print(10, "Foo!")
    Text.putChar(1,0,"Q")

def update(elapsed, globs):
    keysBefore = set(globs.keys)
    pumpEvents(globs)

    globs.emitter.update(elapsed, globs.bullet)
    globs.player.update()
    # Exiting with Escape
    if keycode.SDLK_ESCAPE in globs.keys:
        sdl2.SDL_QUIT()
        sys.exit()

    # Movement
    if keycode.SDLK_d in globs.keys:
        globs.player.position.x += globs.player.speed * elapsed
    if keycode.SDLK_w in globs.keys:
        globs.player.position.y += globs.player.speed * elapsed
    if keycode.SDLK_s in globs.keys:
        globs.player.position.y -= globs.player.speed * elapsed
    if keycode.SDLK_a in globs.keys:
        globs.player.position.x -= globs.player.speed * elapsed

    globs.bulletStateMachine.update(keysBefore, globs.keys, elapsed)
    globs.bullet.update(globs.bulletStateMachine)


def pumpEvents(globs):
    ev = sdl2.SDL_Event()
    while True:
        eventOccurred = sdl2.SDL_PollEvent(ctypes.byref(ev))
        if not eventOccurred:
            return
        elif ev.type == sdl2.SDL_KEYDOWN:
            globs.keys.add(ev.key.keysym.sym)
        elif ev.type == sdl2.SDL_KEYUP:
            globs.keys.discard(ev.key.keysym.sym)
        elif ev.type == sdl2.SDL_QUIT:
            sdl2.SDL_Quit()
            sys.exit()


def draw(globs):
    #globs.framecount += 1
    glClear(GL_COLOR_BUFFER_BIT)
    BufferManager.bind()
    globs.prog.use()
    # globs.hex.draw()

    # glDrawArrays(GL_TRIANGLES, 0, 3)

    # glClear(GL_COLOR_BUFFER_BIT) glScissor(globs.box_x, globs.box_y, 50, 50) glClearColor(
    # globs.bulletStateMachine.chargeAmount, globs.bulletStateMachine.green, globs.bulletStateMachine.blue,
    globs.emitter.draw()
    globs.player.draw()
    globs.bullet.draw()
    Text.draw()

main()
