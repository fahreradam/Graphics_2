import etgg2801
from math2801 import *
from Program import *


class Camera:
    def __init__(self, coi):
        self.lookAt(coi, vec3(0, 1, 0))

    def lookAt(self, coi, up):
        self.coi = vec4(coi.x, coi.y, 0, 1)  # center of interest
        self.up = vec4(up.x, up.y, 0, 0)
        self.right = vec4(self.up.y, -self.up.x, 0, 0)
        self.updateViewMatrix()

    def updateViewMatrix(self):
        cr = -dot(self.coi, self.right)
        cu = -dot(self.coi, self.up)
        self.viewMatrix = mat4(
            self.right.x, self.up.x, 0, 0,
            self.right.y, self.up.y, 0, 0,
            0, 0, 1, 0,
            cr, cu, 0, 1)

    def setUniforms(self):

        Program.setUniform("viewMatrix", self.viewMatrix)


    def pan(self, dx, dy):
        self.coi.x += dx
        self.coi.y += dy
        self.updateViewMatrix()

    def tilt(self, amt):
        M = axisRotation(vec3(0, 0, 1), amt)
        self.right = self.right * M
        self.up = self.up * M
        self.updateViewMatrix()