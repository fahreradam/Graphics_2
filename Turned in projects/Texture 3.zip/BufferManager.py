import array
from Buffer import Buffer
from gl import *
from glconstants import *

vao = 0  # vertex array object
pdata = []
pbuff = None
idata = []
ibuff = None
tdata = []
tbuff = None


def addData(newpdata):
    """Add data to our buffer"""
    global vao, pdata
    if vao != 0:
        # Antibugging
        raise RuntimeError("Cannot add data after pushToGPU() has been called")
    assert type(newpdata) == list
    oldSize = len(pdata) // 3  # get number of points in list
    # divide by 3 because x,y,z
    pdata += newpdata
    return oldSize


def pushToGPU():
    global vao
    global pbuff,tbuff,ibuff
    global pdata,tdata,idata
    pbuff = Buffer( array.array( "f", pdata ) )
    tbuff = Buffer( array.array( "f", tdata ) )   #new
    ibuff = Buffer( array.array( "I", idata ) )
    tmp = array.array("I",[0])
    glGenVertexArrays(1,tmp)
    vao = tmp[0]
    glBindVertexArray(vao)
    ibuff.bind(GL_ELEMENT_ARRAY_BUFFER)
    pbuff.bind(GL_ARRAY_BUFFER)
    glEnableVertexAttribArray(0)
    glVertexAttribPointer( 0, 3, GL_FLOAT, False, 3*4, 0 )
    tbuff.bind(GL_ARRAY_BUFFER)        #new
    glEnableVertexAttribArray(1)            #new
    glVertexAttribPointer( 1, 2, GL_FLOAT, False, 2*4, 0 )  #new


def bind():
    """Make this active"""
    global vao
    if not vao:
        raise RuntimeError("Data hasn't been pushed to GPU")
    glBindVertexArray(vao)


def addIndexedData(*, positiondata, texturedata, indexdata):
    global vao, pdata, tdata, idata
    if vao != 0:
        raise RuntimeError("Cannot add data after pushToGPU() has been called")
    assert type(positiondata) == list
    assert type(texturedata) == list  # new
    assert type(indexdata) == list
    assert len(positiondata) // 3 == len(texturedata) // 2  # new
    startingVertexNumber = len(pdata) // 3
    indexStart = len(idata)
    pdata += positiondata
    tdata += texturedata  # new
    idata += indexdata
    return startingVertexNumber, indexStart * 4
