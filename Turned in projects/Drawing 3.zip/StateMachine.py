import enum
import pysdl2.sdl2.keycode as keycode


class BulletState(enum.Enum):
    IDLE = 1
    CHARGING = 2
    FIRING = 3
    FLASHING = 4


class BulletStateMachine:
    def __init__(self):
        self.currentState = BulletState.IDLE
        self.chargeAmount = 0
        self.time = 0
        self.blue = 0
        self.green = 1

    def update(self, keysbefore, keysnow, elapsed):
        if self.currentState == BulletState.IDLE:
            if keycode.SDLK_SPACE in keysnow and keycode.SDLK_SPACE not in keysbefore:
                self.currentState = BulletState.CHARGING
        if self.currentState == BulletState.CHARGING or self.currentState == BulletState.FLASHING:
            if not keycode.SDLK_SPACE in keysnow:
                self.green = 1
                self.currentState = BulletState.FIRING
        if self.currentState == BulletState.CHARGING:
            self.chargeAmount += elapsed * 0.5
            if self.chargeAmount > 1:
                self.chargeAmount = 1
                self.currentState = BulletState.FLASHING

        if self.currentState == BulletState.FLASHING:
            if self.time <= 0.25:
                self.green = 0
            if 0.25 <= self.time <= 0.5:
                self.green = 1
            if self.time > 0.5:
                self.time = 0
            self.time += elapsed

        if self.currentState == BulletState.FIRING:
            self.chargeAmount = 1
            self.blue = 1
            self.time += elapsed
            if self.time >= 1:
                self.currentState = BulletState.IDLE
                self.blue = 0
                self.chargeAmount = 0
                self.time = 0
