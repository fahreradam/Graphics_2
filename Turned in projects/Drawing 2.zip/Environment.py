import random
import pysdl2.sdl2 as sdl2
import pysdl2.sdl2.keycode as keycode
from gl import *
from glconstants import *


class Emitter:
    def __init__(self, num_squares):
        self.squares = []
        self.amount = num_squares
        self.run = True
        while self.run:
            self.squares.append(Squares())
            if len(self.squares) == self.amount:
                self.run = False

    def draw(self):
        for d in self.squares:
            d.draw()

    def update(self, elapsed):
        for u in self.squares:
            u.update(elapsed)


class Squares:
    def __init__(self):
        self.direction = [random.randint(-1, 1), random.randint(-1, 1)]
        self.position = [random.randint(100, 400), random.randint(100, 400)]
        self.speed = 1
        self.color = (1, 0, 1, 0)
        self.size = 5

    def update(self, elapsed):
        self.position[0] += self.speed * self.direction[0]
        self.position[1] += self.speed * self.direction[1]
        if self.position[0] <= 0:
            self.direction[0] *= -1
        if self.position[0] >= 512 - self.size:
            self.direction[0] *= -1
        if self.position[1] <= 0:
            self.direction[1] *= -1
        if self.position[1] >= 512 - self.size:
            self.direction[1] *= -1

    def draw(self):
        glScissor(self.position[0], self.position[1], self.size, self.size)
        glClearColor(*self.color)
        glClear(GL_COLOR_BUFFER_BIT)

