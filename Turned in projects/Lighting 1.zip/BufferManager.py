import array
from Buffer import Buffer
from gl import *
from glconstants import *

vao = 0  # vertex array object
pdata = []
pbuff = None
idata = []
ibuff = None
ndata = []
nbuff = None
tdata = []
tbuff = None


def addData(newpdata):
    """Add data to our buffer"""
    global vao, pdata
    if vao != 0:
        # Antibugging
        raise RuntimeError("Cannot add data after pushToGPU() has been called")
    assert type(newpdata) == list
    oldSize = len(pdata) // 3  # get number of points in list
    # divide by 3 because x,y,z
    pdata += newpdata
    return oldSize


def pushToGPU():
    global vao
    global pbuff,tbuff, nbuff,ibuff
    global pdata,tdata, ndata, idata
    pbuff = Buffer( array.array( "f", pdata ) )
    tbuff = Buffer( array.array( "f", tdata ) )   #new
    nbuff = Buffer( array.array( "f", ndata ))
    ibuff = Buffer( array.array( "I", idata ) )
    tmp = array.array("I",[0])
    glGenVertexArrays(1,tmp)
    vao = tmp[0]
    glBindVertexArray(vao)
    ibuff.bind(GL_ELEMENT_ARRAY_BUFFER)
    pbuff.bind(GL_ARRAY_BUFFER)
    glEnableVertexAttribArray(0)
    glVertexAttribPointer( 0, 3, GL_FLOAT, False, 3*4, 0 )
    tbuff.bind(GL_ARRAY_BUFFER)        #new

    glEnableVertexAttribArray(1)            #new
    glVertexAttribPointer( 1, 2, GL_FLOAT, False, 2*4, 0 )  #new

    nbuff.bind(GL_ARRAY_BUFFER)
    glEnableVertexAttribArray(2)
    glVertexAttribPointer(2, 3, GL_FLOAT, False, 3 * 4, 0)


def bind():
    """Make this active"""
    global vao
    if not vao:
        raise RuntimeError("Data hasn't been pushed to GPU")
    glBindVertexArray(vao)


def addIndexedData(*, positiondata, texturedata, normaldata, indexdata):
    global vao, pdata, tdata, ndata, idata
    if vao != 0:
        raise RuntimeError("Cannot add data after pushToGPU() has been called")
    assert type(positiondata) == list
    assert type(texturedata) == list  # new
    assert type(indexdata) == list
    assert type(normaldata) == list
    assert len(positiondata) // 3 == len(texturedata) // 2  # new
    startingVertexNumber = len(pdata) // 3
    indexStart = len(idata)
    pdata += positiondata
    tdata += texturedata  # new
    ndata += normaldata
    idata += indexdata
    return startingVertexNumber, indexStart * 4
