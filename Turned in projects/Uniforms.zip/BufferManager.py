import array
from Buffer import Buffer
from gl import *
from glconstants import *

vao = 0  # vertex array object
pdata = []
pbuff = None
idata = []
ibuff = None


def addData(newpdata):
    """Add data to our buffer"""
    global vao, pdata
    if vao != 0:
        # Antibugging
        raise RuntimeError("Cannot add data after pushToGPU() has been called")
    assert type(newpdata) == list
    oldSize = len(pdata) // 3  # get number of points in list
    # divide by 3 because x,y,z
    pdata += newpdata
    return oldSize


def pushToGPU():
    """Push data tp tje GPU"""
    global pbuff, vao, pdata
    if vao != 0:
        raise RuntimeError("Cannot call pushToGPU twice!")
    A = array.array("f", pdata)
    pbuff = Buffer(A)
    A = array.array("I", idata)
    ibuff = Buffer(A)
    tmp = array.array("I", [0])
    glGenVertexArrays(1, tmp)
    vao = tmp[0]
    glBindVertexArray(vao)
    ibuff.bind(GL_ELEMENT_ARRAY_BUFFER)
    pbuff.bind(GL_ARRAY_BUFFER)
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(0, 3, GL_FLOAT, False, 3 * 4, 0)


def bind():
    """Make this active"""
    global vao
    if not vao:
        raise RuntimeError("Data hasn't been pushed to GPU")
    glBindVertexArray(vao)


def addIndexedData(*, positiondata, indexdata):
    global vao, pdata, idata
    if vao != 0:
        raise RuntimeError("Cannot add data after pushTOGPU() has been called")
    assert type(positiondata) == list
    assert type(indexdata) == list
    startingVertexNumber = len(pdata)//3
    indexOffset = len(idata)
    pdata += positiondata
    idata += indexdata
    return startingVertexNumber, indexOffset * 4
