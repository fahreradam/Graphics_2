from Environment import Virus
from Environment import Player
from Camera import *


class GlobalVariables:
    def __init__(self):
        # put globals here...
        self.keys = set()
        self.box_x = 200
        self.box_y = 200
        self.bouncer = Virus()
        self.player = Player()
        self.coi = vec3(0, 1, 0)
        self.eye = vec3(1, 1, 0)
        self.up = vec3(0, 1, 0)
        self.cam = Camera(self.coi, self.eye, self.up)
        self.allmeshes = []
