import math

import etgg2801
from math2801 import *
from Program import *


class Camera:
    def __init__(self, coi, eye, up):
        self.lookAt(coi, eye, up)
        self.projMatrix = mat4(1/math.tan(math.radians(45)), 0,0,0,
                               0, 1/math.tan(math.radians(45)),0,0,
                               0,0, ((2 * 100)/(1-100) + 1), -1,
                               0,0, (2 * 1 * 100)/(1-100), 0)

    def lookAt(self, coi, eye, up):
        self.eye = vec4(eye.x, eye.y, eye.z,1)
        self.coi = vec4(coi.x, coi.y, coi.z,1)
        self.look = normalize(self.coi-self.eye)
        self.right = normalize(
            cross(self.look,vec4(up.x,up.y,up.z,0) ))
        self.up = cross(self.right,self.look)
        self.updateViewMatrix()

    def updateViewMatrix(self):
        cr = -dot(self.eye, self.right)
        cu = -dot(self.eye, self.up)
        cl = -dot(self.eye, -self.look)
        self.viewMatrix = mat4(
            self.right.x, self.up.x, -self.look.x, 0,
            self.right.y, self.up.y, -self.look.y, 0,
            self.right.z, self.up.z, -self.look.z, 0,
            cr, cu, cl, 1)

    def setUniforms(self):

        Program.setUniform("viewMatrix", self.viewMatrix)
        Program.setUniform("projMatrix", self.projMatrix)


    def pan(self, dx, dy):
        self.coi.x += dx
        self.coi.y += dy
        self.updateViewMatrix()

    def tilt(self, amt):
        M = axisRotation(vec3(0, 0, 1), amt)
        self.right = self.right * M
        self.up = self.up * M
        self.updateViewMatrix()

    def strafe(self, deltaRight, deltaUp, deltaLook):
        self.eye += deltaRight * self.right
        self.eye += deltaUp * self.up
        self.eye += deltaLook * self.look
        self.updateViewMatrix()

    def yaw(self, amt):
        M = axisRotation(self.up, amt)
        self.right = self.right * M
        self.look = self.look * M
        self.updateViewMatrix()

    def roll(self, amt):
        M = axisRotation(self.look, amt)
        self.right = self.right * M
        self.up = self.up * M
        self.updateViewMatrix()

    def pitch(self, amt):
        M = axisRotation(self.right, amt)
        self.up = self.up * M
        self.look = self.look * M
        self.updateViewMatrix()

    # friendlier names
    def turn(self, amt):
        self.yaw(amt)

    def walk(self, amt):
        self.strafe(0, 0, amt)
